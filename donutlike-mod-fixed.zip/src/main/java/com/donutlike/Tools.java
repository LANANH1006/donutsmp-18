package com.donutlike;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.AbstractCauldronBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/**
 * Cong cu Amethyst:
 *  - pick/shovel : cup/xeng 3x3 (ngang 3, doc 3, theo huong nhin)
 *  - treeaxe : chat 1 khuc go = do ca cay, la bien mat ngay
 *  - sellaxe : dao ruong/thung/shulker = ban het do ben trong, ruong KHONG bi pha
 *  - bucket  : xo nuoc vo han
 *  - potion  : chuot phai = x2.5 shard trong 30 phut
 */
public class Tools {
    static boolean busy = false;
    static final long POTION_MS = 30L * 60_000L;
    static final double POTION_MULT = 2.5;
    /** uuid -> thoi diem het hieu luc (ms) */
    static final Map<String, Long> BOOST = new HashMap<>();

    static String kind(ItemStack s) {
        if (s == null || s.isEmpty()) return "";
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        if (c == null) return "";
        return c.copyNbt().getString("dl_kind", "");
    }

    static double shardMult(UUID id) {
        Long end = BOOST.get(id.toString());
        return end != null && System.currentTimeMillis() < end ? POTION_MULT : 1.0;
    }

    static void init() {
        // ---- sellaxe: huy bo viec dao ruong, ban do ben trong ----
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) return true;
            if (!kind(sp.getMainHandStack()).equals("sellaxe")) return true;
            Block b = state.getBlock();
            boolean box = b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL || b instanceof ShulkerBoxBlock;
            if (!box || !(be instanceof Inventory inv)) return true;
            double total = 0; int n = 0;
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.isEmpty() || s.get(DataComponentTypes.CUSTOM_DATA) != null) continue; // khong ban do dac biet
                double v = Prices.stack(s);
                if (v <= 0) continue;
                total += v; n += s.getCount();
                inv.setStack(i, ItemStack.EMPTY);
            }
            if (n == 0) { DonutLike.msg(sp, "§cRương trống hoặc không có gì bán được."); return false; }
            inv.markDirty();
            DonutLike.add(sp.getUuid(), total);
            ShopHandler.ting(sp);
            sp.sendMessage(Text.literal("§aĐã bán " + n + " vật phẩm trong rương: §e+$" + Prices.money(total)), true);
            return false;
        });

        // ---- hammer + treeaxe ----
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (busy || world.isClient() || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) return;
            String k = kind(sp.getMainHandStack());
            if (k.equals("treeaxe") && state.isIn(BlockTags.LOGS)) tree(sp, sw, pos);
            else if ((k.equals("pick") || k.equals("hammer")) && state.isIn(BlockTags.PICKAXE_MINEABLE)) plane3(sp, sw, pos, BlockTags.PICKAXE_MINEABLE);
            else if (k.equals("shovel") && state.isIn(BlockTags.SHOVEL_MINEABLE)) plane3(sp, sw, pos, BlockTags.SHOVEL_MINEABLE);
        });

        // ---- xo nuoc Amethyst: khong cho do vao cauldron (se bien thanh xo rong) ----
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (kind(player.getStackInHand(hand)).equals("bucket")
                    && world.getBlockState(hit.getBlockPos()).getBlock() instanceof AbstractCauldronBlock) return ActionResult.FAIL;
            return ActionResult.PASS;
        });

        // ---- potion ----
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            ItemStack s = player.getStackInHand(hand);
            if (kind(s).equals("bucket")) {
                ActionResult r = bucket(sp);
                sp.currentScreenHandler.syncState(); // ep client ve lai dung xo (khong doi thanh xo rong)
                return r;
            }
            if (!kind(s).equals("potion")) return ActionResult.PASS;
            s.decrement(1);
            BOOST.put(sp.getUuid().toString(), System.currentTimeMillis() + POTION_MS);
            sp.getEntityWorld().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 1f, 1f);
            DonutLike.msg(sp, "§d§lx2.5 SHARD §dtrong 30 phút!");
            return ActionResult.SUCCESS;
        });
    }

    /** goi moi 10 tick: nap lai xo nuoc vo han */
    static void tick(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isOf(Items.BUCKET) && kind(st).equals("bucket")) {
                    ItemStack n = new ItemStack(Items.WATER_BUCKET);
                    n.set(DataComponentTypes.CUSTOM_DATA, st.get(DataComponentTypes.CUSTOM_DATA));
                    n.set(DataComponentTypes.CUSTOM_NAME, st.get(DataComponentTypes.CUSTOM_NAME));
                    n.set(DataComponentTypes.LORE, st.get(DataComponentTypes.LORE));
                    p.getInventory().setStack(i, n);
                }
            }
        }
    }

    // ---------- xo nuoc Amethyst ----------
    /** Muc nuoc: 3x3x1. Dat nuoc: 3 ngang x 1 cao. Item giu nguyen (khong doi thanh xo rong => khong mat hieu ung). */
    static ActionResult bucket(ServerPlayerEntity sp) {
        ServerWorld w = sp.getEntityWorld();
        HitResult hr = sp.raycast(5.0, 0f, true);
        if (!(hr instanceof BlockHitResult bhr) || hr.getType() != HitResult.Type.BLOCK) return ActionResult.FAIL;
        BlockPos p = bhr.getBlockPos();
        FluidState fs = w.getFluidState(p);
        if (fs.isOf(Fluids.WATER) && fs.isStill()) {
            int n = 0;
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                BlockPos q = p.add(dx, 0, dz);
                if (w.getBlockState(q).isOf(Blocks.WATER) && w.getFluidState(q).isStill()) {
                    w.setBlockState(q, Blocks.AIR.getDefaultState());
                    n++;
                }
            }
            if (n > 0) w.playSound(null, p, SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 1f, 1f);
            return ActionResult.SUCCESS;
        }
        if (w.getRegistryKey() == net.minecraft.world.World.NETHER) { DonutLike.msg(sp, "§cNước bốc hơi ở đây."); return ActionResult.FAIL; }
        BlockPos t = p.offset(bhr.getSide());
        Direction side = sp.getHorizontalFacing().rotateYClockwise();
        int placed = 0;
        for (int i = -1; i <= 1; i++) {
            BlockPos q = t.offset(side, i);
            BlockState bs = w.getBlockState(q);
            boolean still = bs.getFluidState().isOf(Fluids.WATER) && bs.getFluidState().isStill();
            if ((bs.isAir() || bs.isReplaceable()) && !still) {
                w.setBlockState(q, Blocks.WATER.getDefaultState());
                placed++;
            }
        }
        if (placed > 0) w.playSound(null, t, SoundEvents.ITEM_BUCKET_EMPTY, SoundCategory.BLOCKS, 1f, 1f);
        return ActionResult.SUCCESS;
    }

    // ---------- 3x3 (cu) ----------
    static boolean breakable(ServerWorld w, BlockPos p) {
        BlockState st = w.getBlockState(p);
        if (st.isAir() || st.getHardness(w, p) < 0) return false;
        if (w.getBlockEntity(p) != null) return false; // khong pha ruong/may nung
        return st.getFluidState().isEmpty();
    }

    /** Cup / xeng Amethyst: dao 1 block = dao ca mat 3x3 (ngang 3, doc 3) theo huong dang nhin. */
    static void plane3(ServerPlayerEntity sp, ServerWorld w, BlockPos c, net.minecraft.registry.tag.TagKey<Block> tag) {
        busy = true;
        try {
            Vec3d look = sp.getRotationVec(1f);
            Direction face = Direction.getFacing(look.x, look.y, look.z);
            Direction.Axis ax = face.getAxis();
            for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++) {
                if (a == 0 && b == 0) continue;
                if (sp.getMainHandStack().isEmpty()) return;
                BlockPos p;
                if (ax == Direction.Axis.Y) p = c.add(a, 0, b);       // nhin len/xuong: 3x3 nam ngang
                else if (ax == Direction.Axis.X) p = c.add(0, a, b);  // nhin huong Dong/Tay: 3x3 mat phang Y-Z
                else p = c.add(a, b, 0);                              // nhin huong Nam/Bac: 3x3 mat phang X-Y
                if (!breakable(w, p) || !w.getBlockState(p).isIn(tag)) continue;
                sp.interactionManager.tryBreakBlock(p);
            }
        } finally { busy = false; }
    }

    // ---------- chat ca cay ----------
    static void tree(ServerPlayerEntity sp, ServerWorld w, BlockPos start) {
        busy = true;
        try {
            Set<BlockPos> logs = new LinkedHashSet<>();
            Deque<BlockPos> q = new ArrayDeque<>();
            q.add(start);
            while (!q.isEmpty() && logs.size() < 400) {
                BlockPos c = q.poll();
                for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                    BlockPos n = c.add(dx, dy, dz);
                    if (logs.contains(n) || !w.getBlockState(n).isIn(BlockTags.LOGS)) continue;
                    if (Math.abs(n.getX() - start.getX()) > 8 || Math.abs(n.getZ() - start.getZ()) > 8) continue;
                    logs.add(n);
                    q.add(n);
                }
            }
            // chi do cay that (co la tu nhien ke ben), khong pha nha go
            boolean isTree = false;
            outer:
            for (BlockPos l : logs) {
                for (int dx = -2; dx <= 2; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) {
                    BlockState s = w.getBlockState(l.add(dx, dy, dz));
                    if (s.isIn(BlockTags.LEAVES) && s.contains(LeavesBlock.PERSISTENT) && !s.get(LeavesBlock.PERSISTENT)) { isTree = true; break outer; }
                }
            }
            if (!isTree) return;
            for (BlockPos l : logs) {
                if (sp.getMainHandStack().isEmpty()) break;
                sp.interactionManager.tryBreakBlock(l);
            }
            // la bien mat ngay (roi do binh thuong)
            int removed = 0;
            for (BlockPos l : logs) {
                for (int dx = -3; dx <= 3 && removed < 800; dx++) for (int dy = -3; dy <= 3; dy++) for (int dz = -3; dz <= 3; dz++) {
                    BlockPos n = l.add(dx, dy, dz);
                    BlockState s = w.getBlockState(n);
                    if (s.isIn(BlockTags.LEAVES) && s.contains(LeavesBlock.PERSISTENT) && !s.get(LeavesBlock.PERSISTENT)) {
                        w.breakBlock(n, true, sp);
                        removed++;
                    }
                }
            }
        } finally { busy = false; }
    }
}
