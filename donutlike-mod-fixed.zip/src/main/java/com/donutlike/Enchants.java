package com.donutlike;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

/** Tao do FULL phu phep (elytra, giap, vu khi, cong cu...) cho /shop, /order, /ah. */
public class Enchants {

    /** Loai do: helmet, chest, legs, boots, sword, axe, pick, shovel, hoe, elytra, bow, crossbow, trident, mace, shield, hoac "" neu khong co. */
    static String kind(Item item) {
        String id = Registries.ITEM.getId(item).getPath();
        if (id.endsWith("_helmet")) return "helmet";
        if (id.endsWith("_chestplate")) return "chest";
        if (id.endsWith("_leggings")) return "legs";
        if (id.endsWith("_boots")) return "boots";
        if (id.endsWith("_sword")) return "sword";
        if (id.endsWith("_pickaxe")) return "pick";
        if (id.endsWith("_axe")) return "axe";
        if (id.endsWith("_shovel")) return "shovel";
        if (id.endsWith("_hoe")) return "hoe";
        return switch (id) {
            case "elytra" -> "elytra";
            case "bow" -> "bow";
            case "crossbow" -> "crossbow";
            case "trident" -> "trident";
            case "mace" -> "mace";
            case "shield" -> "shield";
            default -> "";
        };
    }

    static boolean fullable(Item item) { return !kind(item).isEmpty(); }

    /** Item dat tien du de dang "full phu phep" (kim cuong / netherite / elytra / mace / trident...) */
    static boolean premiumGear(Item item) {
        return fullable(item) && Prices.unit(item) >= 100;
    }

    private static void add(ItemStack s, RegistryKey<Enchantment> key, int lvl) {
        var reg = DonutLike.SERVER.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        s.addEnchantment(reg.getOrThrow(key), lvl);
    }

    /** Tra ve 1 item da gan full phu phep. Neu server chua san sang -> item thuong. */
    static ItemStack full(Item item) {
        ItemStack s = new ItemStack(item);
        String k = kind(item);
        if (k.isEmpty() || DonutLike.SERVER == null) return s;
        try {
            add(s, Enchantments.UNBREAKING, 3);
            add(s, Enchantments.MENDING, 1);
            switch (k) {
                case "helmet" -> { add(s, Enchantments.PROTECTION, 4); add(s, Enchantments.RESPIRATION, 3); add(s, Enchantments.AQUA_AFFINITY, 1); }
                case "chest" -> add(s, Enchantments.PROTECTION, 4);
                case "legs" -> { add(s, Enchantments.PROTECTION, 4); add(s, Enchantments.SWIFT_SNEAK, 3); }
                case "boots" -> { add(s, Enchantments.PROTECTION, 4); add(s, Enchantments.FEATHER_FALLING, 4); add(s, Enchantments.DEPTH_STRIDER, 3); }
                case "sword" -> { add(s, Enchantments.SHARPNESS, 5); add(s, Enchantments.LOOTING, 3); add(s, Enchantments.FIRE_ASPECT, 2); add(s, Enchantments.SWEEPING_EDGE, 3); }
                case "axe" -> { add(s, Enchantments.SHARPNESS, 5); add(s, Enchantments.EFFICIENCY, 5); }
                case "pick", "shovel", "hoe" -> { add(s, Enchantments.EFFICIENCY, 5); add(s, Enchantments.FORTUNE, 3); }
                case "bow" -> { add(s, Enchantments.POWER, 5); add(s, Enchantments.PUNCH, 2); add(s, Enchantments.FLAME, 1); }
                case "crossbow" -> { add(s, Enchantments.QUICK_CHARGE, 3); add(s, Enchantments.PIERCING, 4); }
                case "trident" -> { add(s, Enchantments.LOYALTY, 3); add(s, Enchantments.IMPALING, 5); add(s, Enchantments.CHANNELING, 1); }
                case "mace" -> { add(s, Enchantments.DENSITY, 5); add(s, Enchantments.FIRE_ASPECT, 2); add(s, Enchantments.WIND_BURST, 3); }
                default -> { } // elytra, shield: chi Unbreaking 3 + Mending
            }
        } catch (Throwable t) { t.printStackTrace(); }
        return s;
    }
}
