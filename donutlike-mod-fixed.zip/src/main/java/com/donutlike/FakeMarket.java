package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Cho "ao" de choi mot minh:
 *  - /sell : GUI order cua NGUOI MUA AO (ten ao). Click = ban 1 stack, shift+click = ban het (toi da so con can).
 *  - Order cua BAN (/orders create ...) se duoc NGUOI BAN AO giao dan dan neu gia du hop ly.
 */
public class FakeMarket {

    static final String[] FAKE_NAMES = {"Alex_VN", "DonutKing", "xX_Miner_Xx", "Hana", "Bao123", "NoobMaster", "Zephyr", "TanSMP",
        "Minh_PvP", "CrystalGod", "Linh", "ShadowFox", "Kiet_TV", "PandaGamer", "Nguyen_MC", "Thanh2k8", "ObsidianLord", "EnderQueen",
        "Duc_Cpvp", "MeoMeo", "BigTotem", "RaidKing", "FarmBot99", "SkyBlockVN", "Quan_Mine", "TrangPro", "LavaCake", "IronGolem_", "Phuc_SMP", "DragonSlay"};

    static final Item[] POOL = {
        Items.DIAMOND, Items.EMERALD, Items.IRON_INGOT, Items.GOLD_INGOT, Items.NETHERITE_INGOT, Items.COAL, Items.REDSTONE,
        Items.LAPIS_LAZULI, Items.COPPER_INGOT, Items.OBSIDIAN, Items.ENDER_PEARL, Items.BLAZE_ROD, Items.GOLDEN_APPLE, Items.QUARTZ,
        Items.OAK_LOG, Items.COBBLESTONE, Items.DIRT, Items.SAND, Items.BONE, Items.GUNPOWDER, Items.STRING, Items.SLIME_BALL,
        Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.ARROW, Items.WHEAT, Items.CARROT, Items.POTATO, Items.SUGAR_CANE, Items.PUMPKIN,
        Items.MELON_SLICE, Items.COCOA_BEANS, Items.NETHER_WART, Items.GLOWSTONE_DUST, Items.END_STONE, Items.SHULKER_SHELL,
        Items.ANCIENT_DEBRIS, Items.DIAMOND_BLOCK, Items.IRON_BLOCK, Items.COOKED_BEEF, Items.BREAD, Items.TOTEM_OF_UNDYING
    };

    /** Bot chi giao order neu gia >= MIN_RATIO * gia tri item */
    static final double MIN_RATIO = 0.7;

    static class FO {
        String name; Item item; int remaining; double per; boolean ench; long vid = -1;
    }

    static final List<FO> LIST = new ArrayList<>();
    static long bucket = -1;
    static final Random RND = new Random();

    /** Tat ca item co gia (>0) - moi item co 1 order co dinh gia. Tinh 1 lan. */
    static List<Item> ALL = null;
    static List<Item> all() {
        if (ALL == null) {
            List<Item> l = new ArrayList<>();
            for (Item it : net.minecraft.registry.Registries.ITEM) if (Prices.unit(it) > 0) l.add(it);
            l.sort((x, y) -> Double.compare(Prices.unit(y), Prices.unit(x)));
            ALL = l;
        }
        return ALL;
    }

    static String fakeName(Random r) { return FAKE_NAMES[r.nextInt(FAKE_NAMES.length)]; }

    /** 1 order cua bot cho item nay. Gia co dinh theo item (do full phu phep: Prices.enchUnit). bump = cong them % de cac order canh tranh nhau. */
    static FO makeFor(Random r, Item it, double bump) {
        FO o = new FO();
        o.name = fakeName(r);
        o.item = it;
        o.ench = Enchants.premiumGear(it);
        double base = o.ench ? Prices.enchUnit(it) : Math.max(0.5, Prices.unit(it));
        o.per = Math.round(base * (1.0 + bump) * 100.0) / 100.0;
        int stack = Math.max(1, Math.min(64, it.getMaxCount()));
        o.remaining = o.ench ? 1 + r.nextInt(6) : (10_000 + r.nextInt(890_000)) / 100 * 100; // chuc - tram ngan moi order
        return o;
    }

    static FO make(Random r) {
        List<Item> a = all();
        return makeFor(r, a.get(r.nextInt(a.size())), 0);
    }

    /** Vat pham nong dan / quai: nhieu nguoi order nhat (cobble, bone, kelp...). */
    static final java.util.Set<String> FARM = java.util.Set.of("cobblestone", "bone", "kelp", "dried_kelp", "rotten_flesh", "gunpowder",
        "string", "spider_eye", "sugar_cane", "cactus", "arrow", "feather", "leather", "wheat", "carrot", "potato", "sand", "gravel",
        "dirt", "stone", "netherrack", "bamboo", "melon_slice", "pumpkin", "egg", "ink_sac", "slime_ball", "bone_meal", "coal", "iron_ingot");

    /** So order rieng cho 1 item: moi item it nhat 10, item dat tien nhieu hon, item farm (cobble/bone/kelp) nhieu nhat. */
    static int orderCount(Item it) {
        String id = net.minecraft.registry.Registries.ITEM.getId(it).getPath();
        double u = Prices.unit(it);
        int n = 10 + (int) Math.min(40, Math.max(0, Math.log10(Math.max(1, u)) * 8));
        if (FARM.contains(id)) n = 90;
        return n;
    }

    static void ensure() {
        long b = System.currentTimeMillis() / 900_000L; // doi bo order moi 15 phut
        if (b == bucket && !LIST.isEmpty()) return;
        bucket = b;
        LIST.clear();
        Random r = new Random(b * 31 + 7);
        for (Item it : all()) {
            int n = orderCount(it);
            boolean premium = Prices.unit(it) >= 1000;
            for (int i = 0; i < n; i++) {
                // moi order la 1 dong RIENG (khong gop stack). Do dat tien: nhieu nguoi canh tranh nhau, gia nhich dan
                double bump = premium ? i * (0.002 + r.nextDouble() * 0.004) : r.nextDouble() * 0.03;
                LIST.add(makeFor(r, it, bump));
            }
        }
        // gia cao nhat (elytra full phu phep, dau rong, trung rong...) len dau; item re (cobble, bone, kelp) o cac trang sau
        LIST.sort((x, y) -> Double.compare(y.per, x.per));
    }

    // ===== /ah: hang cua BOT (gia cao hon gia order) + hang troll =====
    static final List<Market.Listing> AH = new ArrayList<>();
    static long ahBucket = -1;

    static Market.Listing botListing(Random r, ItemStack st, double price) {
        String n = fakeName(r);
        Market.Listing l = new Market.Listing(UUID.nameUUIDFromBytes(("bot:" + n).getBytes()), n, st, price);
        l.bot = true;
        l.created = System.currentTimeMillis() - r.nextInt(3_600_000);
        return l;
    }

    // ===== /ah VO HAN TRANG: hang bot sinh ra theo so thu tu (khong luu), moi gio doi 1 lan =====
    static final java.util.Set<Long> SOLD = new java.util.HashSet<>();
    static long vBucket = -1;
    static final java.util.Map<String, List<Item>> MATCH = new java.util.HashMap<>();
    static final Object[][] TROLL = {
        {Items.DIRT, 1, 500e9}, {Items.STICK, 1, 1e12}, {Items.COBBLESTONE, 64, 250e9}, {Items.WOODEN_SWORD, 1, 999e9},
        {Items.POISONOUS_POTATO, 1, 300e9}, {Items.DEAD_BUSH, 1, 100e9}, {Items.ROTTEN_FLESH, 16, 750e9}, {Items.SAND, 1, 420e9},
        {Items.OAK_SAPLING, 1, 2e12}, {Items.BOWL, 1, 69e9}, {Items.DIRT, 64, 5e15}, {Items.STICK, 64, 9.9e18}
    };

    static List<Item> matching(String filter) {
        return MATCH.computeIfAbsent(filter, f -> {
            List<Item> l = new ArrayList<>();
            String q = f.replace(' ', '_');
            for (Item it : all()) {
                String idp = net.minecraft.registry.Registries.ITEM.getId(it).getPath();
                if (idp.contains(q) || new ItemStack(it).getName().getString().toLowerCase().contains(f)) l.add(it);
            }
            return l;
        });
    }

    static final long AH_N = 1_000_000_000L * Market.PER_PAGE; // 1 ty trang

    /**
     * Hang bot o vi tri pos (khong luu, sinh theo vi tri). sort: 0 = gia cao nhat truoc, 1 = gia thap nhat truoc, 2 = moi nhat (xao tron).
     * Moi item luon ban 1 stack day (hoac 1 mon do phu phep), gia monotone theo rank => hopper sap xep dung toan bo trang
     * (chinh xac nhat khi loc 1 vat pham: /ah <item>). Gia /ah luon cao hon gia /order (x1.3 .. x2.2 gia tri).
     */
    static Market.Listing virtual(long pos, String filter, int sort) {
        long b = System.currentTimeMillis() / 3_600_000L;
        if (b != vBucket) { vBucket = b; SOLD.clear(); }
        if (pos < 0 || pos >= AH_N) return null;
        List<Item> pool = filter == null ? all() : matching(filter);
        if (pool.isEmpty()) return null;
        long rank = sort == 0 ? pos : sort == 1 ? AH_N - 1 - pos : (pos * 7919L + 12345L) % AH_N;
        int n = pool.size();
        Item it = pool.get((int) (rank % n));
        long tier = rank / n;
        long tiers = (AH_N + n - 1) / n;
        long key = ((long) net.minecraft.registry.Registries.ITEM.getRawId(it) * 100_000_000_000L + rank) * 4096L + n;
        if (SOLD.contains(key)) return null;
        Random r = new Random(key * 0x9E3779B97F4A7C15L + b * 31L + 11);
        // Hang re -> ban le (1 cai / vai cai); hang dat -> ca stack; dat nhat -> nguyen shulker box. So luong KHONG TANG theo rank nen gia van monotone.
        double t = (double) tier / Math.max(1, tiers - 1);       // 0 = dat nhat ... 1 = re nhat
        boolean prem = Enchants.premiumGear(it);
        int sm = prem ? 1 : Math.max(1, Math.min(64, it.getMaxCount()));
        double one = prem ? Prices.enchUnit(it) : Math.max(0.5, Prices.unit(it));
        long cnt; ItemStack st;
        if (t < 0.08) {
            cnt = 27L * sm;
            List<ItemStack> inside = new ArrayList<>();
            for (int i = 0; i < 27; i++) inside.add(prem ? Enchants.full(it) : new ItemStack(it, sm));
            st = new ItemStack(SHULKERS[(int) ((key >>> 3) % SHULKERS.length)]);
            st.set(net.minecraft.component.DataComponentTypes.CONTAINER, net.minecraft.component.type.ContainerComponent.fromStacks(inside));
        } else {
            int c = t < 0.30 ? sm : t < 0.50 ? Math.max(1, sm / 2) : t < 0.70 ? Math.max(1, sm / 4)
                : t < 0.85 ? Math.min(Math.min(sm, 4), Math.max(1, sm / 4)) : 1;
            cnt = c;
            st = prem ? Enchants.full(it) : new ItemStack(it, c);
        }
        double mult = 2.2 - 0.9 * t;                              // rank cang cao -> gia cang cao
        double price = Math.round(one * cnt * mult * 100.0) / 100.0;
        Market.Listing l = botListing(r, st, price);
        l.vid = key;
        l.created = b * 3_600_000L;
        return l;
    }

    // ===== /order VO HAN TRANG theo vat pham: toi da 1 ty trang cho 1 vat pham (khong luu, sinh theo vi tri) =====
    static final int VORDER_PAGES = 1_000_000_000; // 1 ty trang cho 1 vat pham
    static final long VORDER_N = (long) VORDER_PAGES * Market.PER_PAGE;
    static final java.util.Map<Long, Integer> VUSED = new java.util.HashMap<>();
    static long voBucket = -1;

    /** Order ao o vi tri pos (0..N-1). sort: 0 = gia cao nhat truoc, 1 = gia thap nhat truoc, 2 = moi nhat (xao tron gia). */
    static FO virtualOrder(List<Item> pool, long pos, int sort) {
        if (pool.isEmpty() || pos < 0 || pos >= VORDER_N) return null;
        long b = System.currentTimeMillis() / 3_600_000L;
        if (b != voBucket) { voBucket = b; VUSED.clear(); }
        long rank = sort == 0 ? pos : sort == 1 ? VORDER_N - 1 - pos : (pos * 7919L + 12345L) % VORDER_N;
        int n = pool.size();
        Item it = pool.get((int) (rank % n));
        long tier = rank / n;
        long tiers = (VORDER_N + n - 1) / n;
        long key = (long) net.minecraft.registry.Registries.ITEM.getRawId(it) * 100_000_000_000L + rank;
        Random r = new Random(key * 0x9E3779B97F4A7C15L + b * 31L + 5);
        FO o = new FO();
        o.vid = key;
        o.name = fakeName(r);
        o.item = it;
        o.ench = Enchants.premiumGear(it);
        double base = o.ench ? Prices.enchUnit(it) : Math.max(0.5, Prices.unit(it));
        double mult = 1.25 - 0.35 * ((double) tier / Math.max(1, tiers - 1)); // rank cang cao -> gia cang cao
        o.per = Math.round(base * mult * 100.0) / 100.0;
        int stack = Math.max(1, Math.min(64, it.getMaxCount()));
        int total = o.ench ? 1 + r.nextInt(6) : (10_000 + r.nextInt(890_000)) / 100 * 100;
        o.remaining = total - VUSED.getOrDefault(key, 0);
        return o.remaining <= 0 ? null : o;
    }

    static void init() { }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("sell").requires(s -> Admin.on("orders")).executes(c -> { SellGui.open(c.getSource().getPlayerOrThrow()); return 1; }));
    }

    static void open(ServerPlayerEntity p) {
        ensure();
        Market.openOrders(p, 0, null);
    }

    // ===== Nguoi ban ao giao hang cho order cua ban =====
    static void tick(MinecraftServer s) {
        if (!Admin.on("bots")) return;
        if (DonutLike.tick % 20 == 0 && Admin.on("ah")) botBuyAh();   // moi 1s: bot mua hang vua dang sau 5-10s
        if (DonutLike.tick % 20 == 0) botChat(s);
        if (DonutLike.tick % 40 != 0 || !Admin.on("orders")) return;
        for (Market.Order o : Market.ORDERS) {
            if (o.remaining <= 0) continue;
            if (System.currentTimeMillis() - o.created < 3000) continue;
            double unit = Prices.unit(o.template.getItem());
            if (o.perItem < unit * MIN_RATIO) continue;          // gia qua thap -> bot khong giao
            long n = Math.max(1L, (long) (o.remaining * (0.15 + RND.nextDouble() * 0.35)));
            n = Math.min(n, o.remaining);
            o.remaining -= n;
            o.stored += n;                                        // do nam trong order, chu order vao /orders de lay
            String who = FAKE_NAMES[RND.nextInt(FAKE_NAMES.length)];
            ServerPlayerEntity buyer = s.getPlayerManager().getPlayer(o.buyer);
            if (buyer != null && Settings.on(buyer.getUuid(), "trade"))
                DonutLike.msg(buyer, "§a[Order] " + who + " đã giao " + Market.num(n) + "x " + o.template.getName().getString()
                    + (o.remaining > 0 ? " (còn " + Market.num(o.remaining) + ")" : " — order hoàn tất") + " §7→ /orders → Order của bạn để lấy đồ");
        }
    }

    // ===== Chat gia chay lien tuc: bot noi chuyen + tin order/ah (bat/tat trong /settings) =====
    static long nextChat = 0;
    static final String[] CHAT_MSGS = {
        "ai bán {item} rẻ không", "/ah {item} đang rẻ nè", "order {item} giá cao ae vào giao đi", "vừa bán {item} được ${price} luôn",
        "{item} đang lên giá nha", "ai có {item} bán mình mua", "tpa mình với ae", "kèo duel không", "farm spawner sướng thật",
        "baltop tăng nhanh quá", "mới đăng {item} lên ah, ai mua", "selling {item} cheap /ah", "who wants to duel", "anyone selling {item}?",
        "gg", "lag quá", "có ai afk shard không", "order {item} nhiều lắm vào bán đi", "/sell nhanh hơn ah nhiều"};
    static final Item[] SHULKERS = {Items.SHULKER_BOX, Items.BLACK_SHULKER_BOX, Items.WHITE_SHULKER_BOX, Items.RED_SHULKER_BOX, Items.BLUE_SHULKER_BOX, Items.GREEN_SHULKER_BOX};

    static void botChat(MinecraftServer s) {
        long now = System.currentTimeMillis();
        if (now < nextChat) return;
        nextChat = now + 2500 + RND.nextInt(5500);                // 1 dong moi 2.5 - 8s
        List<Item> pool = all();
        if (pool.isEmpty()) return;
        Item it = RND.nextInt(10) < 6 ? POOL[RND.nextInt(POOL.length)] : pool.get(RND.nextInt(pool.size()));
        String item = new ItemStack(it).getName().getString();
        String who = FAKE_NAMES[RND.nextInt(FAKE_NAMES.length)];
        double unit = Math.max(1, Prices.unit(it));
        int k = RND.nextInt(10);
        String line;
        if (k < 4) {
            line = "§7<§f" + who + "§7> §f" + CHAT_MSGS[RND.nextInt(CHAT_MSGS.length)].replace("{item}", item)
                .replace("{price}", Prices.money(unit * (1 + RND.nextInt(64))));
        } else if (k < 7) {
            long amt = (10_000 + RND.nextInt(890_000)) / 100 * 100L;   // bot order chuc - tram ngan mon moi lan
            line = "§6[Order] §f" + who + " §7vừa đặt order §e" + Market.num(amt) + "x " + item + " §7giá §a$" + Prices.money(unit * (1.0 + RND.nextDouble() * 0.25)) + "§7/cái";
        } else if (k < 9) {
            line = "§b[AH] §f" + who + " §7vừa bán §e" + item + " §7giá §a$" + Prices.money(unit * (1.3 + RND.nextDouble() * 0.9) * (1 + RND.nextInt(Math.max(1, Math.min(64, it.getMaxCount())))));
        } else {
            line = "§b[AH] §f" + who + " §7vừa mua §e" + item + " §7giá §a$" + Prices.money(unit * (1.3 + RND.nextDouble() * 0.9) * (1 + RND.nextInt(Math.max(1, Math.min(64, it.getMaxCount())))));
        }
        Text t = Text.literal(line);
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList())
            if (Settings.on(p.getUuid(), "botchat")) p.sendMessage(t, false);
    }

    // ===== Bot mua do dang tren /ah: 5-10s sau khi dang la co nguoi mua ngay =====
    static void botBuyAh() {
        long now = System.currentTimeMillis();
        int bought = 0;
        for (Market.Listing l : new ArrayList<>(Market.LISTINGS)) {
            if (bought >= 10) break;
            if (l.buyAt == 0) l.buyAt = l.created + 5_000 + RND.nextInt(5_001);   // 5 - 10s
            if (now < l.buyAt) continue;
            double fair = Prices.stack(l.stack);
            if (fair <= 0 || l.price / fair > 4.0) continue;        // khong dinh gia duoc / qua dat (>4x) -> bot khong mua
            if (!Market.LISTINGS.remove(l)) continue;
            DonutLike.add(l.seller, l.price);
            bought++;
            String who = FAKE_NAMES[RND.nextInt(FAKE_NAMES.length)];
            ServerPlayerEntity seller = DonutLike.SERVER == null ? null : DonutLike.SERVER.getPlayerManager().getPlayer(l.seller);
            if (seller != null) {
                ShopHandler.ting(seller);
                if (Settings.on(seller.getUuid(), "trade"))
                    DonutLike.msg(seller, "§a[AH] " + who + " đã mua " + l.stack.getName().getString() + " với giá $" + Prices.money(l.price));
            }
        }
    }

    /** Ban cho 1 order cua bot (dung chung cho /sell va /orders) */
    static void sell(ServerPlayerEntity sp, FO o, boolean all) {
        if (o.vid < 0 && !LIST.contains(o)) { DonutLike.msg(sp, "§cOrder này không còn."); return; }
        int limit = all ? o.remaining : Math.min(o.remaining, Math.max(1, o.item.getMaxCount()));
        int given = 0;
        PlayerInventory pi = sp.getInventory();
        for (int i = 0; i < 36 && given < limit; i++) {
            ItemStack s = pi.getStack(i);
            if (s.isEmpty() || !s.isOf(o.item) || s.get(DataComponentTypes.CUSTOM_DATA) != null) continue;
            if (o.ench != s.hasEnchantments()) continue; // order full phu phep chi nhan do co phu phep (va nguoc lai)
            int n = Math.min(s.getCount(), limit - given);
            s.decrement(n);
            given += n;
        }
        if (given == 0) { DonutLike.msg(sp, o.ench ? "§cOrder này cần đồ FULL phù phép trong túi bạn." : "§cBạn không có vật phẩm phù hợp trong túi."); return; }
        double pay = o.per * given;
        DonutLike.add(sp.getUuid(), pay);
        o.remaining -= given;
        if (o.vid >= 0) VUSED.merge(o.vid, given, Integer::sum);
        ShopHandler.ting(sp);
        DonutLike.msg(sp, "§a[Sell] Đã bán " + given + "x " + new ItemStack(o.item).getName().getString()
            + " cho " + o.name + ": §e+$" + Prices.money(pay));
        if (o.remaining <= 0) {
            int idx = LIST.indexOf(o);
            if (idx >= 0) LIST.set(idx, make(RND));
        }
    }
}
