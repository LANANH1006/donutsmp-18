package com.donutlike;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.StringNbtReader;

/** (1.21.11) BLOCK_ENTITY_DATA doi kieu -> doc/ghi qua codec de khong phu thuoc ten ham. */
class BeData {
    static void set(ItemStack s, net.minecraft.nbt.NbtCompound be) {
        var ops = DonutLike.SERVER.getRegistryManager().getOps(NbtOps.INSTANCE);
        var codec = net.minecraft.component.DataComponentTypes.BLOCK_ENTITY_DATA.getCodecOrThrow();
        var v = codec.parse(ops, be).getOrThrow();
        s.set(net.minecraft.component.DataComponentTypes.BLOCK_ENTITY_DATA, v);
    }
    static net.minecraft.nbt.NbtCompound get(ItemStack s) {
        var v = s.get(net.minecraft.component.DataComponentTypes.BLOCK_ENTITY_DATA);
        if (v == null) return null;
        var ops = DonutLike.SERVER.getRegistryManager().getOps(NbtOps.INSTANCE);
        var codec = net.minecraft.component.DataComponentTypes.BLOCK_ENTITY_DATA.getCodecOrThrow();
        NbtElement el = codec.encodeStart(ops, v).getOrThrow();
        return el instanceof net.minecraft.nbt.NbtCompound c ? c : null;
    }
}

/** Luu / doc ItemStack thanh chuoi SNBT de AH khong mat do khi restart. */
public class ItemIO {
    public static String encode(ItemStack s) {
        try {
            var ops = DonutLike.SERVER.getRegistryManager().getOps(NbtOps.INSTANCE);
            return ItemStack.CODEC.encodeStart(ops, s).getOrThrow().toString();
        } catch (Exception e) { e.printStackTrace(); return null; }
    }

    public static ItemStack decode(String str) {
        try {
            var ops = DonutLike.SERVER.getRegistryManager().getOps(NbtOps.INSTANCE);
            NbtElement el = StringNbtReader.readCompound(str);
            return ItemStack.CODEC.parse(ops, el).getOrThrow();
        } catch (Exception e) { e.printStackTrace(); return ItemStack.EMPTY; }
    }
}
