package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

import java.util.List;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** /withdraw (to sec tien), /redeem (ve rank), /suicide */
public class Notes {
    /** Lenh console chay khi doi ve rank. Doi cho hop voi plugin phan quyen cua ban. */
    static final String RANK_COMMAND = "lp user {player} parent set {rank}";

    static NbtCompound data(ItemStack s) {
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? new NbtCompound() : c.copyNbt();
    }

    static void init() {
        // chuot phai to sec -> nap tien
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient() || !Admin.on("notes") || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            ItemStack s = player.getStackInHand(hand);
            if (s.isEmpty() || s.getItem() != Items.PAPER) return ActionResult.PASS;
            NbtCompound n = data(s);
            if (!n.contains("dl_note")) return ActionResult.PASS;
            double v = n.getDouble("dl_note", 0.0);
            s.decrement(1);
            DonutLike.add(sp.getUuid(), v);
            DonutLike.msg(sp, "§aĐã nạp tờ séc: +$" + DonutLike.fmt(v));
            return ActionResult.SUCCESS;
        });
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("withdraw").requires(s -> Admin.on("notes")).then(argument("amount", DoubleArgumentType.doubleArg(1)).executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            double a = Math.floor(DoubleArgumentType.getDouble(c, "amount") * 100) / 100.0;
            if (DonutLike.bal(p.getUuid()) < a) { DonutLike.msg(p, "§cBạn không đủ tiền."); return 0; }
            DonutLike.add(p.getUuid(), -a);
            ItemStack note = new ItemStack(Items.PAPER);
            NbtCompound n = new NbtCompound();
            n.putDouble("dl_note", a);
            n.putLong("dl_id", System.nanoTime()); // moi to sec la duy nhat, khong stack
            note.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
            note.set(DataComponentTypes.CUSTOM_NAME, Text.literal("§aTờ séc §e$" + DonutLike.fmt(a)));
            note.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("§7Chuột phải để nạp tiền vào tài khoản"),
                Text.literal("§7Ký bởi: " + p.getName().getString()))));
            p.getInventory().offerOrDrop(note);
            DonutLike.msg(p, "§aĐã rút $" + DonutLike.fmt(a) + " thành tờ séc. Mất tờ séc = mất tiền, hãy cẩn thận!");
            return 1;
        })));

        // /redeem : doi ve rank dang cam tren tay
        d.register(literal("redeem").requires(s -> Admin.on("notes")).executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            ItemStack s = p.getMainHandStack();
            NbtCompound n = data(s);
            if (s.isEmpty() || !n.contains("dl_rank")) { DonutLike.msg(p, "§cHãy cầm vé rank trên tay."); return 0; }
            String rank = n.getString("dl_rank", "");
            s.decrement(1);
            var srv = DonutLike.SERVER;
            DonutLike.runCmd(srv.getCommandSource(),
                RANK_COMMAND.replace("{player}", p.getName().getString()).replace("{rank}", rank));
            srv.getPlayerManager().broadcast(Text.literal("§6" + p.getName().getString() + " đã kích hoạt rank §e" + rank + "§6!"), false);
            return 1;
        }));

        // /rankvoucher <player> <rank> (op) : tao ve rank (ve co the bi cuop/trao doi)
        d.register(literal("rankvoucher").requires(src -> Admin.isAdmin(src) && Admin.on("notes"))
            .then(argument("player", EntityArgumentType.player())
            .then(argument("rank", StringArgumentType.word()).executes(c -> {
                ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                String rank = StringArgumentType.getString(c, "rank");
                ItemStack v = new ItemStack(Items.NETHER_STAR);
                NbtCompound n = new NbtCompound();
                n.putString("dl_rank", rank);
                n.putLong("dl_id", System.nanoTime());
                v.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
                v.set(DataComponentTypes.CUSTOM_NAME, Text.literal("§6Vé Rank §e" + rank));
                v.set(DataComponentTypes.LORE, new LoreComponent(List.of(Text.literal("§7Cầm trên tay và gõ §e/redeem"))));
                t.getInventory().offerOrDrop(v);
                return 1;
            }))));

        d.register(literal("suicide").requires(s -> Admin.on("suicide")).executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            if (Duels.inDuel(p)) { DonutLike.msg(p, "§cKhông thể dùng khi đang duel."); return 0; }
            p.kill((ServerWorld) p.getEntityWorld());
            return 1;
        }));
    }
}
