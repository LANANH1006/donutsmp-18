DonutLike v1.1 - Fabric 1.21.4 (Java 21 + Fabric Loader + Fabric API 0.119.2+1.21.4)

BUILD LOCAL: cai JDK 21 + Gradle 8.12, mo terminal trong thu muc nay: gradle build
             -> build/libs/donutlike-1.1.0.jar -> bo vao mods (cung Fabric API)
BUILD GITHUB: push len GitHub -> tab Actions -> "Build mod" -> tai artifact "donutlike-mod".
              Muon tao Release: git tag v1.1.0 && git push origin v1.1.0

MOI TRONG v1.1
- Can cu rai rac: moi o 176x176 block co ~60% co 1 can cu (go / gach da 2 tang / ham obsidian),
  ~50% da bi raid (tuong thung, ruong bi lay do, mang nhen, ho bom, vun). Xay khi ban den gan.
  /randombase [intact|raided] (op) de sinh thu ngay canh ban.
- Bang ben phai (sidebar) kieu DonutSMP cu: tien, shards, kills, deaths, playtime, online. /sidebar de bat/tat.
- /baltop /killtop /shardtop /playtop (co hang cua ban o cuoi).

LENH: go /donuthelp trong game.
Duel: /duel bot <noob|normal|pro|cpvp> [tien cuoc]
      /duel custom <mau> <sat thuong> <toc do 0.1-0.6> <giap 0-4> <totem> <crystal true/false>
      /duel leave
Chinh bot o Duels.java (SPECS). Tien/gia o DonutLike.java va bang PRICES.
Chinh can cu o Bases.java (CELL, BASE_CHANCE, loot). Chinh sidebar o Hud.java (buildLines).

MOI TRONG v1.2 (DonutSMP cu)
- /ah (phan trang 45 mon/trang, sap xep, /ah sell <gia> toi da 5 mon, /ah search <ten>) - do do NGUOI CHOI dang, luu file, restart khong mat.
- /orders (alias /order): gia mua cao nhat o trang 1. /orders create <item> <sl> <gia/cai>: tien bi giu (escrow),
  nguoi khac click order de giao do -> tien chuyen cho ho, do bay vao tui nguoi dat. Nguoi dat offline => order huy, hoan tien.
- Combat: /ct /combat (15s), thoat game khi dang tag = chet + rot do, khong dung duoc /spawn /home /rtp /tpa. /pvp bat/tat; spawn 48 block luon khoa PvP.
- /suicide, /withdraw <tien> (to sec giay, chuot phai nap lai), /rankvoucher <player> <rank> (op) + /redeem (cam ve tren tay).
  Doi lenh rank o Notes.RANK_COMMAND (mac dinh lenh LuckPerms).
- Chong lag (AntiLag.java): gop quai "Creeper x100" (chem chet tru 1), don item roi khi >300, khoa no giuong (Nether/End) + Respawn Anchor (ngoai Nether).
- Amethyst: /amethyst <player> <sword|pickaxe|axe|shovel|helmet|chestplate|leggings|boots> (op). Tu huy sau 72h thuc, bao mau tim.
  Quet tui + ender chest moi 10s, ruong thi quet luc mo ruong.

MOI TRONG v1.3 - MENU ADMIN
- /dladmin (hoac /dlmenu, op): mo menu 54 o. Xanh = BAT, do = TAT cho tung tinh nang. Giay/so luong: chuot trai +, chuot phai -, shift x5.
  O Beacon = Master (tat toan bo mod, server chay nhu vanilla). TNT = reset mac dinh.
- Lenh: /dladmin list | toggle <key> | set <key> <so> | master | reset. Thiet lap luu trong config/donutlike.json.
- Tinh nang tat -> lenh tuong ung bi an (can vao lai server de client cap nhat goi y lenh).

MOI TRONG v1.4 (DonutSMP cu)
- /shop 3 tang: menu chinh (Gear/Nether/End/Food/Shard Shop) -> menu con 54 o -> chon so luong (-64 -10 -1 | item | +1 +10 +64, Confirm/Cancel). Sua hang o ShopHandler.java (add("gear", Items.X, gia)).
- MOI item/block deu co gia ban (Prices.java; bang PRICES o DonutLike.java ghi de). Re chuot vao item (client) hien "Sell: $x", ke ca do trong shulker. Tien dang 1 / 100K / 1M / 1B / 1T.
- Sidebar: Money, Shards, Kills, Deaths, Keyall (dem nguoc, het gio +1 shard cho tat ca), Playtime. Chu ky keyall chinh o /lananhadm menu (keyall_minutes).
- /sell : order cua NGUOI MUA AO (FakeMarket.java). Order cua ban (/orders create) duoc nguoi ban ao giao dan neu gia >= 90% gia tri.
- /shardshop : Amethyst (potion x2.5 shard, xo nuoc vo han, cup, cup 3x3, riu chat cay, riu sell) + spawner pig/cow/skeleton/blaze/creeper. SUA GIA SHARD O ShardShop.java (TOOL_PRICE, SPAWNER_PRICE) - minh khong co bang gia shard goc cua DonutSMP.
- /rtp : GUI (co=overworld, netherrack=nether, end stone=end), tim vi tri tung tick nen khong giat.
- /warp afk, khu spawn: /lananhadm buildspawn (xay tai cho dung + dat spawn), /lananhadm buildafk.
- /duel (khong tham so): mod tu chon bot theo giap ban mac. Fix duel bi day ve cho cu (chunk dau truong gio duoc nap + giu).
- /lananhadm : CHI admin. Chua co chu: op go /lananhadm setowner <ten>. Sau do lenh bi an voi nguoi khac (do/khong goi y). money|shards give|take|set <player> <1k|1m|1b|1t>, amethyst, menu, buildspawn, buildafk.
- Can cu rai rac day hon (o luoi 112, 85%).

MOI TRONG v1.5 - SPAWNER KIEU DONUTSMP (Spawners.java)
- Chuot phai spawner dang dat bang spawner cung loai = gop +1 (Shift = gop ca stack trong tay).
- Dat spawner moi: Shift + dat = dat ca stack thanh 1 spawner xN.
- Dao bang Silk Touch: lay 1 ra khoi stack; Shift + dao = lay ca stack (khong Silk Touch thi khong dao duoc).
- Spawner KHONG sinh quai, tu sinh DO vao kho moi 10s (bang LOOT trong Spawners.java). Chuot phai (khong Shift) = mo kho: click trai lay 1 stack, click phai ban het loai do, nut Ban tat ca.
- Spawner mua o /shardshop da co RequiredPlayerRange=0 (khong sinh quai that).

MOI TRONG v1.6 - AMETHYST TOOLS + FIX SHOP
- /amethyst <player> <pick_silk|pick_fortune|shovel_silk|shovel_fortune|treeaxe_silk|treeaxe_fortune|sellaxe_silk|sellaxe_fortune|bucket|potion|...>
  Cup/xeng: dao 1 lan = 3 block thang hang (dai 3, ngang 1). Rieu: treeaxe (chat ca cay), sellaxe (dao ruong = ban do). Enchant: Unbreaking 3, Mending, Efficiency 5 + Silk Touch HOAC Fortune 3.
- Xo nuoc Amethyst: chuot phai len nuoc = muc 3x3x1; chuot phai len block = dat nuoc 3 ngang x 1 cao. Khong bao gio mat hieu ung Amethyst.
- /shardshop co du 8 loai cong cu + xo + potion + spawner (menu 45 o).
- /shop: mua xong KHONG thoat ra man hinh chinh nua (o lai man chon so luong de mua tiep).
- Tui day: /dladmin -> "Shop: day tui van mua". BAT = do roi xuong dat, TAT = khong cho mua khi tui day.

MOI TRONG v1.7 (v10)
- Menu kho spawner: them nut - / so luong / + (o 45, 46, 47). Chuot trai=+-1, chuot phai=+-10, Shift=+-64.
  Click trai item = lay <so luong>, click phai = ban <so luong>. Tui day (khi tat "Shop: day tui van mua") -> chi lay vua du cho trong.
- /ah: mua do hoac huy ban khi tui day -> bi chan (hoac roi xuong dat neu bat "Shop: day tui van mua" trong /dladmin).

MOI TRONG v1.8
- Cup/xeng Amethyst: dao 1 block = dao ca mat 3x3 (ngang 3, doc 3) theo huong dang nhin (nhin len/xuong = 3x3 nam ngang).
- /shardshop: chon spawner / do Amethyst -> man hinh chon so luong co - / + (-64 -10 -1 | +1 +10 +64) roi XAC NHAN MUA.
- Xo nuoc Amethyst: dat nuoc / muc nuoc KHONG con bien thanh xo thuong nua (client khong du doan, server giu nguyen xo,
  khong do duoc vao cauldron). Can cai mod o CA client lan server.
- Menu spawner: moi o = 1 stack, co TRANG. Mui ten trai/phai o hang duoi (o 45 / 53) de doi trang.
  Skeleton: bone xep truoc, arrow xep cuoi. Nut DROPPER (o 49) = lay het do dang hien o trang do.
  Chai EXP (o 50) = nhan exp spawner tich luy (pig/cow 2, skeleton/creeper/zombie/spider 5, blaze 10 moi spawner / 10s).
- /ah: them nut chest (o 50) = SELL BOX: dat do vao o, chinh gia bang nut, bam DANG BAN.
- Bot: bot mua do tren /ah (gia <= 1.6x gia tri, cang re cang nhanh), bot giao order cua ban (gia >= 70% gia tri),
  order cua bot hien chung trong /orders (click de giao, shift+click giao toi da). Bat/tat bot trong /dladmin ("bots").
- Nguoi choi that: /ah, /ah sell, /orders create deu hoat dong giua nguoi voi nguoi (mua do, giao order nguoi khac).
- Tat server: order dang cho duoc hoan tien (truoc day order khong luu file nen mat tien giu).

MOI TRONG v1.9
- /order (alias /orders): hon 1500 order (~35 trang), MOI item co gia deu co 1 order, gia CO DINH theo Prices. Vat pham dat (elytra, dau rong, netherite,
  totem, beacon...) co 4-9 nguoi order canh tranh, gia hon kem nhau vai %. Gia cao nhat len dau => elytra / trung rong / dau rong o nhung hang dau.
- /order <vat pham> (vd /order elytra): chi hien order cua vat pham do de giao hang. Gioi tinh nang goi y ten item khi go lenh.
- Do gear (kim cuong/netherite/elytra/mace/trident/bow/crossbow/shield) o /order la order "FULL phu phep": phai giao do co phu phep.
- /shop: them muc "Enchanted" (slot 16) ban do FULL phu phep (Prices.enchUnit = gia goc x ENCH_MULT 3). Gia = gia /order => khong lech.
  Doi he so o Prices.ENCH_MULT. Sua danh sach o ShopHandler (addEnch).
- /ah <vat pham> (vd /ah elytra): loc nhanh. /ah search <ten> van dung.
- /ah co hang cua BOT (bat/tat bang "bots" trong /dladmin): gia luon CAO HON gia order (x1.25-2.15), do full phu phep, + hang TROLL
  (cuc dat 500B, que 1T, da cuoi 250B...). Doi moi gio. Sua danh sach troll o FakeMarket.ensureAh().
- build.yml: build 2 ban (1.21.4 va 1.21.11) cung luc, tu lay Yarn/Loader/Fabric API qua meta.fabricmc.net. Sua o muc "matrix".

MOI TRONG v1.10 (chi ban 1.21.11)
- /sellgui (cung la /sell): bo do vao ruong, dong (ESC/E) la ban het. Moi vat pham 1 gia rieng; do khong ban duoc duoc tra lai tui.
- Sell multi: ban cang nhieu mon (6000 mon) he so cang cao, toi da x3. Xem bang /sellmulti.
- /order: moi vat pham co nhieu order rieng (it nhat 10, do dat/farm nhieu hon: cobble, bone, kelp... 90). Khong gop stack, hien 1 cai, so can giao nam o lore. Chuot phai o nut trang = nhay 10 trang.
- /shop: muc 1 la Blocks (tat ca block xay nha), muc Mob & Farm, Sach phu phep (moi loai 1 dong, xep theo nhom giap/vu khi/cong cu/cung/chung). Do full phu phep + sach: 1 click la mua 1 mon (chuot phai chon so luong).
- Don vi tien: K M B T Qa Qi Sx Sp Oc No Dc (moi bac x1000). Nhap lenh: 1qa, 1q, 5qi, 2sx, 3dc ...
- /baltop co bot top tien. /home mo GUI 5 giuong (trang = chua dat, xanh nuoc bien = da dat), moi map 5 home rieng.
- /ah: vo han trang (~2 ty trang): chuot phai +-100 trang, shift +-10.000 trang. Hang cua nguoi choi o trang dau, sau do la hang bot (gia cao hon order, co hang troll).
- Bot mua /ah va giao order nhanh hon (3-5 giay).
- Can cu moi: farm KELP, farm COBBLE (3 may phat da), HAM NGAM obsidian, PHAO DAI. Khong con nha go. /randombase van dung.
- Bot AFK (nguoi choi ao) dung quanh spawn + tu xoa quai vat quanh spawn (tat bang /dladmin: afkbots, spawnclean).
- /lananhadm: nguoi mo the gioi (host) hoac op deu dung duoc.

MOI TRONG v1.10.1
- /lananhadm kill <player|@a> (admin). Giet nguoi choi / bot duel => +1 kill, hien thong tin kill (chat + action bar).
- /order <vat pham>: toi da 10.000 trang order cho 1 vat pham. Hopper (o 48) doi: gia cao nhat -> gia thap nhat -> moi nhat. /ah cung co hopper nay.
- /sellgui: bam cuc vang (o 49) = ban luon, khong can dong GUI (dong GUI van ban phan con lai).

MOI TRONG v1.10.2
- /order <item> va /ah: toi da 1 TY trang cho 1 vat pham. Nhay trang: /order page <so> [item], /ah page <so> [item]; mui ten: phai +-100, Shift-trai +-10.000, Shift-phai +-1.000.000.
- Hopper sap xep (gia cao nhat -> thap nhat -> moi nhat) ap dung ca hang cua bot. /ah bot: moi item 1 stack day, gia x1.3..x2.2 gia tri (luon cao hon /order). Loc 1 vat pham thi sap xep chinh xac nhat.
- Sell multi theo TONG TIEN DA BAN (gia goc): x1.1=10M, x1.2=50M, x1.3=100M, x1.5=500M, x1.75=1B, x2=5B, x2.25=10B, x2.5=50B, x2.75=100B, x3=500B (toi da x3). Sua o SellGui.TIERS. /sellmulti xem tien do.
- Spawner: kho item + exp KHONG gioi han. Pha spawner: tra toi da 2304 stack, phan du ban lay tien (tranh lag server). Nhan exp: tung dot toi da 2.1 ty exp.
- /shop: them Giap (tat ca loai), Mau ren (smithing template, 300/ nang netherite 1000 gia tri ban), Vu khi & cong cu, Redstone, TAT CA vat pham. Mui ten trang: chuot phai nhay 10 trang.

MOI TRONG v1.10.3
- /order: so luong toi da 100.000.000.000.000.000 (tram trieu ty) / order. Order luu file; do duoc giao nam TRONG order, chu order vao /orders -> "Order cua ban" (ender chest, o 50): click = lay do ve tui, Shift+click = huy order (hoan tien phan chua giao).
- /ah bot: hang re ban le (1 cai/vai cai), hang dat ban ca stack, dat nhat la nguyen shulker box day do. Hopper van sap xep dung.
- /ah sell: 5-10s sau khi dang co bot mua ngay (neu gia <= 4 lan gia tri). Bot order moi lan 10.000 - 900.000 mon. Chat gia chay lien tuc 2.5-8s/dong (order, ah, chat).
- /baltop: bot co so du tang lien tuc theo thoi gian.
- /settings (hoac /setting): bat/tat TPA, nhan tien /pay, chat & hoat dong cho, thong bao mua/ban, thong bao kill, bang ben phai, am thanh.
- gradle.properties + fabric.mod.json chinh sang Minecraft 1.21.11 (yarn 1.21.11+build.4, loader 0.18.4, fabric api 0.141.1+1.21.11).
